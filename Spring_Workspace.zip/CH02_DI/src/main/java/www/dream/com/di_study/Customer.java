package www.dream.com.di_study;

import org.springframework.stereotype.Repository;

import lombok.NonNull;
import lombok.RequiredArgsConstructor;

@Repository
@RequiredArgsConstructor
public class Customer {
/*
	@NonNull
	private String name;
	private String address;
	@NonNull
	private boolean sex;
*/
	
}
