package www.dream.com.di_study;

import org.springframework.stereotype.Repository;

@Repository
public class Chef {

}
