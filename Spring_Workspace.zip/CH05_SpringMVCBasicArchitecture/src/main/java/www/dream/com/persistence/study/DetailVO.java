package www.dream.com.persistence.study;

import lombok.Data;

@Data
public class DetailVO {
	private String type;
	private String info;
}
