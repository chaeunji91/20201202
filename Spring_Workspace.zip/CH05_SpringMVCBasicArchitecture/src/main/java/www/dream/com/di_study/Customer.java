package www.dream.com.di_study;

import org.springframework.stereotype.Repository;

import lombok.RequiredArgsConstructor;

@Repository
@RequiredArgsConstructor
public class Customer {
	/*
	@NonNull
	private String name; //스프링 컨테이너의 객체에 있니?
	//프리미티그 타입이 아닌, 객체와 객체끼리 의존성을 주입받음
	//customer의 hong은 불러올 수 없었음
	private String address;
	@NonNull
	private boolean sex;
	*/
}
